Blackmagic
==========
Memory reading and Writing for C# / VB / .Net Applications.
